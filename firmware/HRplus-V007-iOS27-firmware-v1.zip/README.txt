HR+ V007 iOS 27 patch v1 — FIRMWARE ONLY

Exact tested device profile: A5G_BY_G23_M05_ST_007_20260122_L
Matching AB1562AE or a short V7 label is not sufficient.

This ZIP contains left/right Airoha FOTA packages. They are intentionally
identical, as were the original packages for this exact profile.
Verify SHA256SUMS.txt before use.

These are not Android installers. Use only an already-established compatible
dual-earbud FOTA workflow and assign each named file to the corresponding side.
No import workflow through official BullSuper or FlyCC is validated here.
The separately published Android APK is the provided installation route with
exact-profile and bundled-file checks.

Keep both earbuds outside the case, with more than 20% charge each, near the
Android device through transfer and restart. Wait for final success; 100%
transfer alone does not mean restart is complete. Do not start another update
while waiting. Experimental flashing can make an incompatible device unusable;
recovery is not guaranteed.

The version remains V7/V007 after the patch. Do not reflash merely because the
version number is unchanged. Later official updates may overwrite the patch.

Initial pairing and music in both earbuds were reported working on one pair
with iPhone 17 / iOS 27.0. Other features, revisions and OS versions are not
validated. See PATCH.md and VALIDATION.md for the exact change and test scope.
